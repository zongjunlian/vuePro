import Vue              from 'vue';
import index            from './index.vue';
import i18n             from './i18n';
import { ElementUI }    from './ui';



    new Vue(
        {
            el: '#index',
            i18n,
            components: { index },
            template: '<index></index>'
        }
    );
