import Vue              from 'vue';
import VueCookie        from 'vue-cookie';
import VueResource      from 'vue-resource';
import App              from './App.vue';
import router           from './router';
import store            from './store';
import i18n             from './i18n';
import { ElementUI }    from './ui';



    Vue.use(VueCookie);
    Vue.use(VueResource), window.$http = Vue.http;

    // 定义 Vue.http.interceptors 拦截请求
    Vue.http.interceptors.push(
        ($req, $next) => {

            let $loading, $login;

            if ($req.loading === true) $loading = ElementUI.Loading.service();

            if ($req.login !== false) $login = true;

            if ($req.emulateJSON !== false) $req.emulateJSON = true;

            // 拦截响应
            $next(
                ($res) => {

                    if ($loading) $loading.close();

                    if ($login) /* if (0) top.location.href = '' */;

                }
            );

        }
    );



    new Vue(
        {
            el: '#app',
            router,
            store,
            i18n,
            components: { App },
            template: '<app></app>'
        }
    );
