<style scoped lang="scss" src="./input-aptdatepicker-component.scss"></style>

<i18n>
    {
        "zh-CN": {

        }
    }
</i18n>

<template>
    <div class="input-aptdatepicker-component" :class="{ '@null': !value, '@clearable': clearable, '@disabled': disabled }">

        <!-- input-value -->
        <div v-if="!value" class="input-value @null">
            {{ placeholder }}
        </div>

        <div v-else class="input-value">
            {{ value | formatDate }}
        </div>

        <!-- el-date-picker -->
        <el-date-picker
            :type="type"
            :value="value" @input="$emit('input', $event)"
            :placeholder="placeholder"
            :clearable="clearable"
            :disabled="disabled">
        </el-date-picker>

    </div>
</template>

<script type="text/jsx">

    export default {

        props: {

            type: {
                type: String
            },

            value: {
                type: String | Date
            },

            placeholder: {
                type: String
            },

            clearable: {
                type: Boolean
            },

            disabled: {
                type: Boolean
            }

        },

        filters: {

            formatDate($date) {

                return $date.getFullYear() + '-' + ('0' + ($date.getMonth() + 1)).slice(-2) + '-' + ('0' + $date.getDate()).slice(-2);

            }

        },

        data() {

            return {};

        }

    }

</script>
