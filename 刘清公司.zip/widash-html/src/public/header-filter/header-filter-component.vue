<style scoped lang="scss" src="./header-filter-component.scss"></style>

<i18n>
    {
        "zh-CN": {

        }
    }
</i18n>

<template>
    <div class="header-filter-component">
        <slot></slot>
    </div>
</template>

<script type="text/jsx">

    export default {

        props: {

        },

        data() {

            return {};

        }

    }

</script>
