<style scoped lang="scss" src="./card-value-component.scss"></style>

<i18n>
    {
        "zh-CN": {

        }
    }
</i18n>

<template>
    <div class="card-value-component" :class="{ '@short': !sub }">

        <!-- title -->
        <div class="card-value-title">
            {{ title }}
        </div>

        <!-- value -->
        <div class="card-value-value">
            <span class="card-value-before">
                <slot name="value-before"></slot>
            </span>
            <span class="card-value-value">
                {{ value | formatThousandBit }}
            </span>
            <span class="card-value-after">
                <slot name="value-after"></slot>
            </span>
        </div>

        <!-- sub -->
        <div v-if="sub" class="card-value-sub">
            <div class="card-value-title">
                {{ sub.title }}
            </div>
            <div v-for="value in sub.value" class="card-value-value">
                <i v-if="value[1]" class="widash-icon" :class="{ '@base-trend_solid': value[1] === 'up', '@base-decline_solid': value[1] === 'down' }"></i> {{ value[0] | formatThousandBit }}
            </div>
        </div>

    </div>
</template>

<script type="text/jsx">

    export default {

        props: {

            title: {
                type: String
            },

            value: {
                type: Number | String
            },

            sub: {
                // {
                //     title: '值',
                //     value: [
                //         ['20%', 'up'],
                //         ['20%', 'down'],
                //         [100000]
                //     ]
                // }
                type: Object
            }

        },

        filters: {

            formatThousandBit($value) {

                if (typeof $value === 'number') $value = String($value).replace(/(\d)(?=(?:\d{3})+(?:\.|$))/g, '$1,');

                return $value;

            }

        },

        data() {

            return {};

        }

    }

</script>
