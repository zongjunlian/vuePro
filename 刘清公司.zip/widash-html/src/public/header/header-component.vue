<style scoped lang="scss">

    .header-component {

    }

</style>

<i18n>
    {
        "zh-CN": {

        }
    }
</i18n>

<template>
    <div class="header-component">
        header-component
    </div>
</template>

<script type="text/jsx">

    export default {

        props: {

        },

        computed: {

        },

        watch: {

        },

        methods: {

        },

        mounted() {

        },

        data() {

            return {};

        }

    }

</script>
