<style scoped lang="scss" src="./input-aptselect-component.scss"></style>

<i18n>
    {
        "zh-CN": {

        }
    }
</i18n>

<template>
    <div class="input-aptselect-component" :class="{ '@null': !String(value), '@multiple': multiple, '@disabled': disabled }">

        <!-- input-value -->
        <div v-if="!String(value)" class="input-value @null">
            {{ placeholder }}
        </div>

        <div v-else-if="!multiple" class="input-value" :style="{ 'max-width': maxWidth }">
            {{ value }}
        </div>

        <!-- el-select -->
        <el-select
            :value="value" @input="$emit('input', $event)"
            :placeholder="placeholder"
            :clearable="clearable"
            :multiple="multiple"
            :disabled="disabled"
            :collapse-tags="collapseTags">
            <slot></slot>
        </el-select>

    </div>
</template>

<script type="text/jsx">

    export default {

        props: {

            value: {
                type: String | Number | Boolean | Array
            },

            placeholder: {
                type: String
            },

            clearable: {
                type: Boolean
            },

            multiple: {
                type: Boolean
            },

            disabled: {
                type: Boolean
            },

            maxWidth: {
                type: String
            },

            collapseTags: {
                type: Boolean
            }

        },

        data() {

            return {};

        }

    }

</script>
