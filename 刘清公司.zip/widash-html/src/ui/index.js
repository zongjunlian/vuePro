import Vue                          from 'vue';
import ElementUI                    from 'element-ui'; import './element-ui.scss';
import HeaderComponent              from '@public/header/header-component';
import HeaderFilterComponent        from '@public/header-filter/header-filter-component';
import InputAptdatepickerComponent  from '@public/input-aptdatepicker/input-aptdatepicker-component';
import InputAptselectComponent      from '@public/input-aptselect/input-aptselect-component';



    // 定义 $v
    let $v = Vue.prototype.$v = window.$v = {

        theme: 'default',

        paging: {
            layout      : 'total, sizes, prev, pager, next, jumper',
            pageSizes   : [5, 10, 20, 50],
            pageSize    : 10,
            pagerCount  : 5
        }

    };



    // 定义 element-ui methods
    ElementUI.Tabs.components.TabNav.methods.changeTab = function () {};

    ElementUI.Tabs.components.TabNav.methods.setFocus = function () {};

    ElementUI.Table.components.TableBody.methods.handleExpandClick = ElementUI.Table.methods.toggleRowExpansion = function ($row, $e) {

        if ($row.children.length > 20) {

            let a = $row.children.splice(20);

            let push = () => {

                $row.children.push(...a.splice(0, 20));

                if (a.length) window.setTimeout(push, 20);

            };

            push();

        }

        this.store.toggleRowExpansion($row);

    };



    Vue.use(ElementUI);
    Vue.component('header-component', HeaderComponent);
    Vue.component('header-filter-component', HeaderFilterComponent);
    Vue.component('input-aptdatepicker-component', InputAptdatepickerComponent);
    Vue.component('input-aptselect-component', InputAptselectComponent);

    export { ElementUI };
