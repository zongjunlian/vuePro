<style scoped lang="scss" src="./hello-component.scss"></style>

<i18n>
    {
        "zh-CN": {
            "hello": "你好！"
        }
    }
</i18n>

<template>
    <div class="page-component">
        <header-filter-component>

            <input-aptselect-component v-model="el.value_12" placeholder="列表条件" clearable>
                <el-option v-for="(option, i) in el.value_11" :key="i" :label="option.label" :value="option.value"></el-option>
            </input-aptselect-component>

            <input-aptdatepicker-component type="date" v-model="el.value_13" placeholder="日期条件" clearable></input-aptdatepicker-component>

        </header-filter-component>

        <div class="wrapper-container @right">
            <div class="wrapper-container">

                <!-- 基础 -->
                <div class="wrapper-container">
                    <div class="content-container @large">

                        <!-- 大号按钮 -->
                        <blockquote>
                            <el-button size="large" class="@normal" disabled>大号按钮</el-button>
                            <el-button size="large" class="@normal">大号按钮</el-button>
                            <el-button size="large" class="@light-colour">大号按钮</el-button>
                            <el-button size="large" class="@light-gray-colour">大号按钮</el-button>
                        </blockquote>

                        <!-- 中号按钮 -->
                        <blockquote>
                            <el-button size="medium" class="@normal" disabled>中号按钮</el-button>
                            <el-button size="medium" class="@normal">中号按钮</el-button>
                            <el-button size="medium" class="@light-colour">中号按钮</el-button>
                            <el-button size="medium" class="@light-gray-colour">中号按钮</el-button>
                        </blockquote>

                        <!-- 小号按钮 -->
                        <blockquote>
                            <el-button size="small" class="@normal" disabled>小号按钮</el-button>
                            <el-button size="small" class="@normal">小号按钮</el-button>
                            <el-button size="small" class="@light-colour">小号按钮</el-button>
                            <el-button size="small" class="@light-gray-colour">小号按钮</el-button>
                        </blockquote>

                    </div>
                    <div class="content-container @large">

                        <!-- 文本按钮 -->
                        <blockquote>
                            <el-button type="text">文本按钮</el-button>
                            <el-button type="text" disabled>文本按钮</el-button>
                        </blockquote>

                        <!-- 单选框 -->
                        <blockquote>
                            <el-radio v-model="el.value_21" label="1">单选框</el-radio>
                            <el-radio v-model="el.value_21" label="2">单选框</el-radio>
                            <el-radio v-model="el.value_22" label="3" disabled>单选框</el-radio>
                            <el-radio v-model="el.value_22" label="4" disabled>单选框</el-radio>
                        </blockquote>

                        <!-- 复选框 -->
                        <blockquote>
                            <el-checkbox v-model="el.value_31">复选框</el-checkbox>
                            <el-checkbox v-model="el.value_32">复选框</el-checkbox>
                            <el-checkbox v-model="el.value_33" disabled>复选框</el-checkbox>
                            <el-checkbox v-model="el.value_34" disabled>复选框</el-checkbox>
                            <el-checkbox :indeterminate="el.value_35">复选框</el-checkbox>
                        </blockquote>

                    </div>
                    <div class="content-container @small">

                        <!-- 开关 -->
                        <blockquote>
                            <el-switch v-model="el.value_43" active-text="上传" inactive-text="上传" disabled></el-switch>
                            <el-switch v-model="el.value_41" active-text="上传" inactive-text="上传"></el-switch>
                            <el-switch v-model="el.value_42" active-text="上传" inactive-text="上传"></el-switch>
                        </blockquote>

                        <!-- 标签 -->
                        <blockquote>
                            <el-tag>标签</el-tag>
                            <el-tag closable>可关闭的标签</el-tag>
                        </blockquote>

                        <!-- 可关闭的标签 -->
                        <blockquote>
                            <el-tag>多行内容的<br>标签</el-tag>
                            <el-tag closable><span class="el-tag__content">多行内容的<br>可关闭的标签</span></el-tag>
                        </blockquote>

                    </div>
                    <div class="content-container @small">

                        <!-- 单行文字提示 -->
                        <blockquote>
                            <el-tooltip placement="bottom" content="单行文字提示">
                                <el-button class="widash-button @light-gray-colour" size="small">单行文字提示</el-button>
                            </el-tooltip>
                        </blockquote>

                        <!-- 多行文字提示 -->
                        <blockquote>
                            <el-tooltip placement="bottom">
                                <div slot="content">
                                    多行文字提示<br/>
                                    多行文字提示
                                </div>
                                <el-button class="widash-button @light-gray-colour" size="small">多行文字提示</el-button>
                            </el-tooltip>
                        </blockquote>

                        <!-- 带有标题的文字提示 -->
                        <blockquote>
                            <el-tooltip placement="bottom">
                                <div slot="content">
                                    <div class="el-tooltip__title">带有标题的文字提示</div>
                                    <div class="el-tooltip__content">带有标题的文字提示带有标题的文字提示带有标题的文字提示带有标题的文字提示带有标题的文字提示</div>
                                </div>
                                <el-button class="widash-button @light-gray-colour" size="small">带有标题的文字提示</el-button>
                            </el-tooltip>
                        </blockquote>

                    </div>
                    <div class="content-container @small">

                        <!-- 消息 -->
                        <blockquote>
                            <el-button class="widash-button @light-gray-colour" size="small" @click="handlerMessage('info', '这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息')">消息</el-button>
                            <el-button class="widash-button @light-gray-colour" size="small" @click="handlerMessage('', '这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息 这是一条消息')">没有 icon 的消息</el-button>
                        </blockquote>

                        <!-- 成功、警告、错误的消息 -->
                        <blockquote>
                            <el-button class="widash-button @light-gray-colour" size="small" @click="handlerMessage('success', '这是成功一条消息')">成功</el-button>
                            <el-button class="widash-button @light-gray-colour" size="small" @click="handlerMessage('warning', '这是警告一条消息')">警告</el-button>
                            <el-button class="widash-button @light-gray-colour" size="small" @click="handlerMessage('error', '这是错误一条消息')">错误</el-button>
                        </blockquote>

                        <!-- 消息提示、确认消息 -->
                        <blockquote>
                            <el-button class="widash-button @light-gray-colour" size="small" @click="handlerAlert()">消息提示</el-button>
                            <el-button class="widash-button @light-gray-colour" size="small" @click="handlerConfirm()">确认消息</el-button>
                        </blockquote>

                    </div>
                    <div class="content-container @small">

                        <!-- 输入框 -->
                        <blockquote>
                            <el-input v-model="el.value_51" placeholder="输入框"></el-input>
                        </blockquote>

                        <!-- 可清空的输入框 -->
                        <blockquote>
                            <el-input v-model="el.value_51" placeholder="可清空的输入框" clearable></el-input>
                        </blockquote>

                        <!-- 禁用的输入框 -->
                        <blockquote>
                            <el-input v-model="el.value_51" placeholder="禁用的输入框" disabled></el-input>
                        </blockquote>

                    </div>
                    <div class="content-container @small">

                        <!-- 搜索输入框 -->
                        <blockquote>
                            <el-input v-model="el.value_52" prefix-icon="widash-icon @top-search" placeholder="搜索输入框"></el-input>
                        </blockquote>

                        <!-- 可清空的搜索输入框 -->
                        <blockquote>
                            <el-input v-model="el.value_52" prefix-icon="widash-icon @top-search" placeholder="可清空的搜索输入框" clearable></el-input>
                        </blockquote>

                        <!-- 禁用的搜索输入框 -->
                        <blockquote>
                            <el-input v-model="el.value_52" prefix-icon="widash-icon @top-search" placeholder="禁用的搜索输入框" disabled></el-input>
                        </blockquote>

                    </div>
                    <div class="content-container @small">

                        <!-- 日期输入框 -->
                        <blockquote>
                            <el-date-picker v-model="el.value_53" type="date" placeholder="日期输入框" :clearable="false"></el-date-picker>
                        </blockquote>

                        <!-- 可清空的日期输入框 -->
                        <blockquote>
                            <el-date-picker v-model="el.value_53" type="date" placeholder="可清空的日期输入框"></el-date-picker>
                        </blockquote>

                        <!-- 禁用的日期输入框 -->
                        <blockquote>
                            <el-date-picker v-model="el.value_53" type="date" placeholder="禁用的日期输入框" disabled></el-date-picker>
                        </blockquote>

                    </div>
                    <div class="content-container @small">

                        <!-- 多行输入框 -->
                        <blockquote>
                            <el-input v-model="el.value_54" type="textarea" placeholder="多行输入框"></el-input>
                        </blockquote>

                        <!-- 禁用的多行输入框 -->
                        <blockquote>
                            <el-input v-model="el.value_54" type="textarea" placeholder="禁用的多行输入框" disabled></el-input>
                        </blockquote>

                    </div>
                    <div class="content-container @small">

                        <!-- 下拉列表 -->
                        <blockquote>
                            <el-select v-model="el.value_62" placeholder="下拉列表">
                                <el-option v-for="(option, i) in el.value_61" :key="i" :label="option.label" :value="option.value"></el-option>
                            </el-select>
                        </blockquote>

                        <!-- 可清空的下拉列表 -->
                        <blockquote>
                            <el-select v-model="el.value_62" placeholder="可清空的下拉列表" clearable>
                                <el-option v-for="(option, i) in el.value_61" :key="i" :label="option.label" :value="option.value"></el-option>
                            </el-select>
                        </blockquote>

                        <!-- 禁用的下拉列表 -->
                        <blockquote>
                            <el-select v-model="el.value_62" placeholder="禁用的下拉列表" disabled>
                                <el-option v-for="(option, i) in el.value_61" :key="i" :label="option.label" :value="option.value"></el-option>
                            </el-select>
                        </blockquote>

                        <!-- 多选下拉列表 -->
                        <blockquote>
                            <el-select v-model="el.value_63" placeholder="多选的下拉列表" multiple collapse-tags>
                                <el-option v-for="(option, i) in el.value_61" :key="i" :label="option.label" :value="option.value"></el-option>
                            </el-select>
                        </blockquote>

                    </div>
                    <div class="content-container @small">

                        <!-- 聪明的下拉列表 -->
                        <blockquote>
                            <input-aptselect-component v-model="el.value_64" placeholder="聪明的下拉列表" clearable>
                                <el-option v-for="(option, i) in el.value_61" :key="i" :label="option.label" :value="option.value"></el-option>
                            </input-aptselect-component>
                        </blockquote>

                        <!-- 聪明的多选下拉列表 -->
                        <blockquote>
                            <input-aptselect-component v-model="el.value_65" placeholder="聪明的多选下拉列表" multiple collapse-tags>
                                <el-option v-for="(option, i) in el.value_61" :key="i" :label="option.label" :value="option.value"></el-option>
                            </input-aptselect-component>
                        </blockquote>

                    </div>
                </div>

                <!-- 照片墙 -->
                <div class="wrapper-container">
                    <div class="content-container @max">
                        <photo-wall-component :data="photoWall"></photo-wall-component>
                    </div>
                </div>

                <!-- 表格 -->
                <div class="wrapper-container">
                    <div class="content-container @max">
                        <el-table :data="elTable" border stripe>
                            <el-table-column prop="0" label="品牌"></el-table-column>
                            <el-table-column prop="1" label="地区" width="200px"></el-table-column>
                            <el-table-column prop="2" label="场所" width="200px"></el-table-column>
                            <el-table-column prop="3" label="进店客流人次" class-name="el-table-column__number" width="200px"></el-table-column>
                            <el-table-column prop="4" label="周边客流人次" class-name="el-table-column__number" width="200px"></el-table-column>
                            <el-table-column prop="5" label="进店率" class-name="el-table-column__number" width="82px" fixed="right"></el-table-column>
                        </el-table>
                    </div>
                </div>

                <!-- 图表 -->
                <div class="wrapper-container">
                    <div class="content-container @large">
                        <echarts-pie-component v-bind="chartPie">
                            <template slot="panel">
                                slot panel
                            </template>
                        </echarts-pie-component>
                    </div>
                    <div class="content-container @large">
                        <echarts-bar-component v-bind="chartBar">
                            <template slot="panel">
                                slot panel
                            </template>
                        </echarts-bar-component>
                    </div>
                    <div class="content-container @large">
                        <echarts-line-component v-bind="chartLine">
                            <template slot="panel">
                                slot panel
                            </template>
                        </echarts-line-component>
                    </div>
                    <div class="content-container @large">
                        <echarts-heatmap-component v-bind="chartHeatmap">
                            <template slot="panel">
                                slot panel
                            </template>
                        </echarts-heatmap-component>
                    </div>
                    <div class="content-container @large">
                        <echarts-scatter-component v-bind="chartScatter">
                            <template slot="panel">
                                slot panel
                            </template>
                        </echarts-scatter-component>
                    </div>
                    <div class="content-container @large">
                        <echarts-funnel-component v-bind="chartFunnel">
                            <template slot="panel">
                                slot panel
                            </template>
                        </echarts-funnel-component>
                    </div>
                    <div class="content-container @max">
                        <echarts-valdistmap-component v-bind="chartValdistmap">
                            <template slot="panel">
                                slot panel
                            </template>
                        </echarts-valdistmap-component>
                    </div>
                </div>

            </div>

            <!-- 右侧栏、值卡片 -->
            <div class="wrapper-container">
                <div class="content-container">
                    <card-value-component v-bind="cardValue1"></card-value-component>
                </div>
                <div class="content-container">
                    <card-value-component v-bind="cardValue2"></card-value-component>
                </div>
            </div>

        </div>

    </div>
</template>

<script type="text/jsx">

    import CardValueComponent           from '@public/card-value/card-value-component';
    import EchartsBarComponent          from '@public/echarts-bar/echarts-bar-component';
    import EchartsFunnelComponent       from '@public/echarts-funnel/echarts-funnel-component';
    import EchartsHeatmapComponent      from '@public/echarts-heatmap/echarts-heatmap-component';
    import EchartsLineComponent         from '@public/echarts-line/echarts-line-component';
    import EchartsPieComponent          from '@public/echarts-pie/echarts-pie-component';
    import EchartsScatterComponent      from '@public/echarts-scatter/echarts-scatter-component';
    import EchartsValdistmapComponent   from '@public/echarts-valdistmap/echarts-valdistmap-component';
    import PhotoWallComponent           from '@public/photo-wall/photo-wall-component';
    import Service                      from './hello-service';



    export default {

        components: {
            CardValueComponent,
            EchartsBarComponent,
            EchartsFunnelComponent,
            EchartsHeatmapComponent,
            EchartsLineComponent,
            EchartsPieComponent,
            EchartsScatterComponent,
            EchartsValdistmapComponent,
            PhotoWallComponent
        },

        methods: {

            handlerMessage($type, $message) {

                this.$message(
                    {
                        type: $type,
                        message: $message
                    }
                );

            },

            handlerAlert() {

                this.$alert('这是一条消息提示', '提示',
                    {
                        confirmButtonText: '确定',
                        confirmButtonClass: '@normal'
                    }
                );

            },

            handlerConfirm() {

                this.$confirm('这是一条确认消息', '确认',
                    {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        confirmButtonClass: '@normal',
                        cancelButtonClass: '@light-gray-colour'
                    }
                ).then(() => {});

            }

        },

        data() {

            return {
                el: {
                    value_11: [
                        { label: '你好', value: '你好' }
                    ],
                    value_12: '',
                    value_13: '',
                    value_21: '1',
                    value_22: '3',
                    value_31: true,
                    value_32: false,
                    value_33: true,
                    value_34: false,
                    value_35: true,
                    value_41: false,
                    value_42: true,
                    value_43: true,
                    value_51: '',
                    value_52: '',
                    value_53: '',
                    value_54: '',
                    value_61: [
                        { label: '北京市', value: '北京市' },
                        { label: '上海市', value: '上海市' },
                        { label: '天津市', value: '天津市' },
                        { label: '重庆市', value: '重庆市' },
                        { label: '云南省', value: '云南省' },
                        { label: '河北省', value: '河北省' },
                        { label: '吉林省', value: '吉林省' },
                        { label: '宁夏回族自治区', value: '宁夏回族自治区' },
                        { label: '四川省', value: '四川省' },
                        { label: '新疆维吾尔族自治区', value: '新疆维吾尔族自治区' },
                    ],
                    value_62: '',
                    value_63: [],
                    value_64: '',
                    value_65: []
                },
                photoWall: [
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'male', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' },
                    { name: 'rain', sex: 'female', photo: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552637858330&di=7a72f1bb5e700844b6f9cb61a29ab7da&imgtype=0&src=http%3A%2F%2Ftx.haiqq.com%2Fuploads%2Fallimg%2F150319%2F1614053917-13.jpg' }
                ],
                elTable: [
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%'],
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%'],
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%'],
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%'],
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%'],
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%'],
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%'],
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%'],
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%'],
                    ['雅诗兰黛', '北京市 / 朝阳区', '万达广场', '705', '326', '21.6%']
                ],
                cardValue1: {
                    title: '值卡片',
                    value: 1000000,
                    sub: {
                        title: '环比',
                        value: [
                            ['20%', 'up'],
                            ['20%', 'down'],
                            [1000000]
                        ]
                    }
                },
                cardValue2: {
                    title: '值卡片',
                    value: 100000
                },
                chartPie: {
                    width: '100%',
                    height: '400px',
                    option: {
                        title: {
                            text: '饼图'
                        },
                        legend: {
                            data: [
                                '21-30 岁',
                                '31-40 岁',
                                '41-50 岁',
                                '51-99 岁'
                            ]
                        },
                        series: [
                            {
                                data: [
                                    { name: '21-30 岁', value: 2130 },
                                    { name: '31-40 岁', value: 3140 },
                                    { name: '41-50 岁', value: 4150 },
                                    { name: '51-99 岁', value: 1199 }
                                ]
                            }
                        ]
                    }
                },
                chartBar: {
                    width: '100%',
                    height: '400px',
                    option: {
                        title: {
                            text: '柱状图'
                        },
                        legend: {
                            data: [
                                '店内顾客',
                                '周边顾客'
                            ]
                        },
                        xAxis: {
                            data: [
                                '21-30 岁',
                                '21-40 岁',
                                '41-50 岁',
                                '51-99 岁'
                            ]
                        },
                        series: [
                            { name: '店内顾客', data: [2130, 3140, 4150, 1199] },
                            { name: '周边顾客', data: [4260, 6280, 8300, 1999] }
                        ]
                    }
                },
                chartLine: {
                    width: '100%',
                    height: '400px',
                    option: {
                        title: {
                            text: '折线图'
                        },
                        legend: {
                            data: [
                                '店内顾客',
                                '周边顾客'
                            ]
                        },
                        xAxis: {
                            data: [
                                '21-30 岁',
                                '21-40 岁',
                                '41-50 岁',
                                '51-99 岁'
                            ]
                        },
                        series: [
                            { name: '店内顾客', data: [2130, 3140, 4150, 1199] },
                            { name: '周边顾客', data: [4260, 6280, 8300, 1999] }
                        ]
                    }
                },
                chartHeatmap: {
                    width: '100%',
                    height: '400px',
                    option: {
                        title: {
                            text: '笛卡尔热力图'
                        },
                        xAxis: {
                            data: [
                                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11',
                                '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'
                            ]
                        },
                        yAxis: {
                            data: [
                                '2019/1/1',
                                '2019/1/2',
                                '2019/1/3',
                                '2019/1/4',
                                '2019/1/5',
                                '2019/1/6',
                                '2019/1/7'
                            ]
                        },
                        series: [
                            {
                                data: [
                                    5, 1, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, 2, 4, 1, 1, 3, 4, 6, 4, 4, 3, 3, 2, 5,
                                    7, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, 5, 2, 2, 6, 9, 11, 6, 7, 8, 12, 5, 5, 7, 2,
                                    1, 1, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, 3, 2, 1, 9, 8, 10, 6, 5, 5, 5, 7, 4, 2, 4,
                                    7, 3, NaN, NaN, NaN, NaN, NaN, NaN, 1, NaN, 5, 4, 7, 14, 13, 12, 9, 5, 5, 10, 6, 4, 4, 1,
                                    1, 3, NaN, NaN, NaN, 1, NaN, NaN, NaN, 2, 4, 4, 2, 4, 4, 14, 12, 1, 8, 5, 3, 7, 3, NaN,
                                    2, 1, NaN, 3, NaN, NaN, NaN, NaN, 2, NaN, 4, 1, 5, 10, 5, 7, 11, 6, NaN, 5, 3, 4, 2, NaN,
                                    1, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, 1, NaN, 2, 1, 3, 4, NaN, NaN, NaN, NaN, 1, 2, 2, 6
                                ]
                            }
                        ]
                    }
                },
                chartScatter: {
                    width: '100%',
                    height: '400px',
                    option: {
                        title: {
                            text: '散点图'
                        },
                        xAxis: {
                            data: [
                                '教育',
                                '理财',
                                '旅行',
                                '交通',
                                '娱乐'
                            ]
                        },
                        series: [
                            { data: [20, 39, 52, 75, 90] },
                            { data: [27, 39, 54, 69, 82] },
                            { data: [29, 42, 59, 67, 83] },
                            { data: [22, 37, 53, 66, 97] },
                            { data: [24, 33, 48, 62, 75] }
                        ]
                    }
                },
                chartFunnel: {
                    width: '100%',
                    height: '400px',
                    option: {
                        title: {
                            text: '漏斗图'
                        },
                        legend: {
                            data: [
                                '教育',
                                '理财',
                                '旅行'
                            ]
                        },
                        series: [
                            {
                                data: [
                                    { name: '教育', value: 20 },
                                    { name: '理财', value: 30 },
                                    { name: '旅行', value: 50 }
                                ]
                            }
                        ]
                    }
                },
                chartValdistmap: {
                    width: '100%',
                    height: '480px',
                    option: {
                        title: {
                            text: '价值分布地图'
                        },
                        geo: {
                            map: '国'
                        },
                        series: [
                            {
                                data: [
                                    { name: '辽', value: 1 },
                                    { name: '吉', value: 2 },
                                    { name: '黑', value: 3 },
                                    { name: '浙', value: 4 },
                                    { name: '粤', value: 5 },
                                    { name: '渝', value: 6 },
                                    { name: '津', value: 8 },
                                    { name: '沪', value: 11 },
                                    { name: '京', value: 16 }
                                ]
                            }
                        ]
                    }
                }
            };

        }

    }

</script>
