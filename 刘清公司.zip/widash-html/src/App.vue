<style lang="css" src="../static/iconfont/iconfont.css"></style>
<style lang="scss" src="./ui-component.scss"></style>
<style lang="scss" src="./App.scss"></style>

<template>
    <div id="app">

        <!-- 需要缓存的视图 -->
        <keep-alive>
            <router-view v-if="$router.isKeepAlive($route)"></router-view>
        </keep-alive>

        <!-- 正常的视图 -->
        <router-view v-if="!$router.isKeepAlive($route)"></router-view>

    </div>
</template>

<script type="text/jsx">

    export default {
        name: 'App',

        watch: {

            '$route.path' () {

                this.$nextTick(
                    () => {

                        let keepAlive;

                        if ((keepAlive = this.$children[0]) && (keepAlive = keepAlive.$vnode) && (keepAlive = keepAlive.parent)) {

                            this.$router.keepAliveKey = keepAlive.componentInstance.keys;
                            this.$router.keepAliveCache = keepAlive.componentInstance.cache;

                        }

                    }
                );

            }

        },

        data() {

            return {};

        }

    }

</script>
