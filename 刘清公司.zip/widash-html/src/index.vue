<style lang="css" src="../static/iconfont/iconfont.css"></style>
<style lang="scss" src="./ui-component.scss"></style>
<style lang="scss" src="./index.scss"></style>

<i18n>
    {
        "zh-CN": {
            "leftLevel1Anchor_collect"  : "收藏",
            "leftLevel1Anchor_report"   : "报表",
            "leftLevel1Anchor_device"   : "设备",
            "leftLevel1Anchor_app"      : "应用",
            "leftLevel1Anchor_system"   : "系统",
            "leftLevel2Header_fixed"    : "固定面板",
            "leftLevel2Header_unfixed"  : "取消固定"
        }
    }
</i18n>

<template>
    <div id="index">

        <div class="left-container">

            <div class="left-logo">
                <i class="widash-icon @left-logo"></i>
            </div>

            <div class="left-user">
                <a class="left-anchor">
                    <i class="widash-icon @left-user"></i>
                </a>
            </div>

            <div class="left-level1">
                <a class="left-anchor">
                    <i class="widash-icon @left-collect"></i>{{ $t('leftLevel1Anchor_collect') }}
                </a>
                <a class="left-anchor">
                    <i class="widash-icon @left-report"></i>{{ $t('leftLevel1Anchor_report') }}
                </a>
                <a class="left-anchor">
                    <i class="widash-icon @left-device"></i>{{ $t('leftLevel1Anchor_device') }}
                </a>
                <a class="left-anchor">
                    <i class="widash-icon @left-app"></i>{{ $t('leftLevel1Anchor_app') }}
                </a>
                <a class="left-anchor">
                    <i class="widash-icon @left-system"></i>{{ $t('leftLevel1Anchor_system') }}
                </a>
            </div>

            <div class="left-level2">

                <div class="left-level2-header">
                    <el-button class="widash-button @light-colour" size="small">
                        <i class="widash-icon @base-unfixed"></i> {{ $t('leftLevel2Header_unfixed') }}
                    </el-button>
                </div>

                <div class="left-level2-content">
                    <el-menu>
                        <el-submenu index="1">
                            <span slot="title">
                                客流统计
                            </span>
                            <el-menu-item index="1-1">

                                <el-menu slot="title" mode="horizontal">
                                    <el-submenu index="1-1" popper-class="left-level3">
                                        <span slot="title">实时客流</span>
                                        <el-menu-item index="1-1-1">
                                            <span slot="title">实时追踪</span>
                                        </el-menu-item>
                                        <el-menu-item index="1-1-2">
                                            <span slot="title">上网顾客</span>
                                        </el-menu-item>
                                        <el-menu-item index="1-1-3">
                                            <span slot="title">流量数据</span>
                                        </el-menu-item>
                                    </el-submenu>
                                </el-menu>

                            </el-menu-item>
                            <el-menu-item index="1-2">
                                <span slot="title">客流趋势分析</span>
                            </el-menu-item>
                            <el-menu-item index="1-3">
                                <span slot="title">客流时段分析</span>
                            </el-menu-item>
                            <el-menu-item index="1-4">
                                <span slot="title">客流排行分析</span>
                            </el-menu-item>
                            <el-menu-item index="1-5">
                                <span slot="title">客流对比分析</span>
                            </el-menu-item>
                            <el-menu-item index="1-6">
                                <span slot="title">探针客流分析</span>
                            </el-menu-item>
                            <el-menu-item index="1-7">
                                <span slot="title">顾客画像</span>
                            </el-menu-item>
                        </el-submenu>
                        <el-menu-item index="2">
                            <span slot="title">顾客行为分析</span>
                        </el-menu-item>
                        <el-menu-item index="3">
                            <span slot="title">联网数据</span>
                        </el-menu-item>
                        <el-menu-item index="4">
                            <span slot="title">餐饮数据</span>
                        </el-menu-item>
                        <el-menu-item index="5">
                            <span slot="title">营销数据</span>
                        </el-menu-item>
                        <el-menu-item index="6">
                            <span slot="title">小票数据</span>
                        </el-menu-item>
                        <el-menu-item index="7">
                            <span slot="title">定制报表</span>
                        </el-menu-item>
                        <el-menu-item index="8">
                            <span slot="title">自定义</span>
                        </el-menu-item>
                    </el-menu>
                </div>

            </div>

        </div>

        <div class="page-container">
            <iframe src="./App.html#/_/hello"></iframe>
        </div>

    </div>
</template>

<script type="text/jsx">

    export default {
        name: 'index',

        data() {

            return {};

        }

    }

</script>
