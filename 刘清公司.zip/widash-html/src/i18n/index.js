import Vue              from 'vue';
import VueI18n          from 'vue-i18n';
import ElementUIL       from 'element-ui/lib/locale';
import ElementUIL_enUS  from 'element-ui/lib/locale/lang/en';
import ElementUIL_zhCN  from 'element-ui/lib/locale/lang/zh-CN';
import Lang_enUS        from './lang.en-US';
import Lang_zhCN        from './lang.zh-CN';



    Vue.use(VueI18n);

    let i18n = new VueI18n(
        {
            locale: 'zh-CN',
            messages: {
                'en-US': {
                    ...ElementUIL_enUS,
                    ...Lang_enUS
                },
                'zh-CN': {
                    ...ElementUIL_zhCN,
                    ...Lang_zhCN
                }
            }
        }
    );

    // 定义 element-ui i18n
    ElementUIL.i18n(($key, $value) => { i18n.t($key, $value) });

    // 定义 $l
    Vue.prototype.$l = window.$l = ($value) => { i18n.locale = $value };



    export default i18n;
