import equals       from 'equals';
import Vue          from 'vue';
import VueRouter    from 'vue-router';
import RouterKeeper from './keeper';



    Vue.use(VueRouter);

    let router = new VueRouter(
        {
            routes: [

                {
                    path: '/',
                    redirect: '/_/hello'
                },

                {
                    path: '/_/hello',
                    component: () => import('@/components/_/hello/hello-component')
                }

            ]
        }
    );

    // 定义 router.beforeEach[0] 检查权限
    router.beforeEach(
        ($to, $from, $next) => {

            router.beforeHooks[0] = ($to, $from, $next) => {

                if ($to.matched.length) {

                    let exclude = [

                        // null

                    ];

                    if (exclude.indexOf($to.matched[0].path) !== -1 || RouterKeeper.inspect($to.matched[0].path)) $next();

                    else $next(exclude[0]);

                }

            };

            RouterKeeper.init(router.beforeHooks[0], $to, $from, $next);

        }
    );

    // 定义 router.beforeEach[1] 检查 URL
    router.beforeEach(
        ($to, $from, $next) => {

            router.beforeHooks.splice(1, 1);

            // 如果在对话框出现时，刷新了浏览器
            // 那么重定向 URL
            //
            // 因为此时的 URL 包含对话框的 route
            // 所以重定向 URL
            //

            if ((/^([\s\S]+?)(?:\/[^\/]+?-dialog\/[\s\S]+?)$/).test($to.path)) $next(RegExp.$1);

            else $next();

        }
    );

    // 定义 router.beforeEach[2] 检查 isKeepAlive
    // 在 App.vue 中
    //
    //     <keep-alive>
    //         <router-view v-if="$router.isKeepAlive($route)"></router-view>
    //     </keep-alive>
    //
    //     watch: {
    //
    //         '$route.path' () {
    //
    //             this.$nextTick(
    //                 () => {
    //
    //                     let keepAlive;
    //
    //                     if ((keepAlive = this.$children[0]) && (keepAlive = keepAlive.$vnode) && (keepAlive = keepAlive.parent)) {
    //
    //                         this.$router.keepAliveKey = keepAlive.componentInstance.keys;
    //                         this.$router.keepAliveCache = keepAlive.componentInstance.cache;
    //
    //                     }
    //
    //                 }
    //             );
    //
    //         }
    //
    //     }
    //
    router.beforeEach(
        ($to, $from, $next) => {

            if ($to.matched.length) {

                let a, b;

                // 假设这个 if 块在进入页面时执行
                if (($to = $to.matched[ $to.matched.length - 1 ]).meta.keepAliveWith) {

                    if (!(a = $from.matched[ $from.matched.length - 1 ]) || (a !== $to && !a.parent)) $to.meta.isKeepAlive = true;

                }

                // 假设这个 if 块在离开页面时执行
                if ($from.matched.length) {

                    // 如果是页面子路由
                    if ($to.parent) {

                        // 如果是对话框 [首页]
                        if ((/-dialog\/index$/).test($to.path)) $to.meta.isKeepAlive = ($to.meta.isKeepAlive !== false);

                    }

                    // 如果是页面路由
                    else if (a = ($from = $from.matched[ $from.matched.length - 1 ]).meta.keepAliveWith) {

                        if (!$from.meta.isKeepAlive) delete $from.meta.keepAliveWith;

                        do {

                            if (a.indexOf($to.path) !== -1) {

                                if (b = $to.meta.keepAliveWith) b.parent = a; else $to.meta.keepAliveWith = Object.assign([], a);

                                if (b = $from.meta.keepAliveWith) if (b.parent) delete b.parent;

                            }

                            else if (!equals($to.meta.keepAliveWith, a)) delete router.keepAliveCache[ router.keepAliveKey.splice(-1) ];

                        }

                        while (a = a.parent);

                    }

                }

            }

            $next();

        }
    );

    // 定义 router.isKeepAlive
    router.isKeepAlive = ($route) => {

        // 如果子路由的 isKeepAlive = false、父路由的 isKeepAlive = true
        // 那么子路由的组件不会正确渲染
        //
        // 因为子路由的组件被认为不在 <keep-alive> 中、父路由的组件在 <keep-alive> 中
        // 所以向上查找 isKeepAlive
        //

        let r, i;

        if ((i = $route.matched.length) > 1) {

            for (i -= 2; r = $route.matched[i]; i--) {

                if (r.meta.isKeepAlive) return true;

            }

        }

        else return $route.meta.isKeepAlive;

    };



    export default router;
