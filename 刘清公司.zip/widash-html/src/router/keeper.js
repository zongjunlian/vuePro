
    let map = [

    ];

    let jur = {

    };

    let keeper = {

        init($next, ...$p) {

            // let success = ($res) => {
            //
            //     let a, i;
            //
            //     for (i = 0; a = $res.body.data[i]; i++) {
            //
            //         jur[a] = true;
            //
            //     }
            //
            //     // 执行下一步
            //     if ($next) $next(...$p);
            //
            // };
            //
            // $http.post('url', null, { login: false }).then(success);

            if ($next) $next(...$p);

        },

        inspect($p) {

            let $jur, a, i;

            for ($jur = true, i = map.length - 1; a = map[i]; i--) {

                if ($p.indexOf(a.path) !== -1) {

                    $jur = jur[a.jur];

                    break;

                }

            }

            return $jur;

        },

        able($key) {

            return jur[$key];

        }

    };



    export default keeper;
